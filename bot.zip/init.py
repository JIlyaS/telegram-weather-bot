import telebot
from load import data

bot = telebot.TeleBot(data["token"])
