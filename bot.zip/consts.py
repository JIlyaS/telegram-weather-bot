MAIN_STATE = 'main_state'
CITY_STATE = 'city_state'
WEATHER_DATE_STATE = 'weather_date_state'
SETTINGS_STATE = 'settings_state'
CITY_QUESTION = 'Какой город ещё интересует?'
ERROR_MESSAGE = 'Я тебя не понял!'
START_KEYBOARD_LIST = ['Погода', 'Настройки']
MONTHS = ['январь', 'февраль', 'март', 'апрель', 'май', 'июнь', 'июль', 'август', 'сентябрь', 'октябрь', 'ноябрь', 'декабрь']
